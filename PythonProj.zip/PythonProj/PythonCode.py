from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Util.Padding import pad, unpad


# Data Digest
fp = 'C:\\Downloads\\OptionalPython.docx'
def hash_file(fp):
    h = SHA256.new()
    with open(fp, 'rb') as f:
        while True:
            chunk = f.read(1024)
            if len(chunk) == 0:
                break
            h.update(chunk)
    return h.hexdigest()

# Data Encryption
def encrypt_file(key, fp):
    data = ''
    with open(fp, 'rb') as f:
        data = f.read()
    cipher = AES.new(key, AES.MODE_ECB)
    ciphert = cipher.encrypt(pad(data, AES.block_size))
    with open('encrypted_data.bin', 'wb') as f:
        f.write(ciphert)

# Data Decryption
def decrypt_file(key, fp):
    ciphert = ''
    with open(fp, 'rb') as f:
        ciphert = f.read()
    cipher = AES.new(key, AES.MODE_ECB)
    plaintext = unpad(cipher.decrypt(ciphert), AES.block_size)
    with open('decrypted_data.docx', 'wb') as f:
        f.write(plaintext)

# Symmetric key
key = b'InformatSecurity'  

# Hash
original_hash = hash_file('C:\\Downloads\\OptionalPython.docx')

# Encrypt
encrypt_file(key, 'C:\\Downloads\\OptionalPython.docx')

# Decrypt
decrypt_file(key, 'encrypted_data.bin')

# Hash the decrypted file
decrypted_hash = hash_file('decrypted_data.docx')

# Data Integrity Verification
print('Data integrity:', original_hash == decrypted_hash)
